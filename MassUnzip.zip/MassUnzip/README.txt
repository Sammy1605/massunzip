MASSUNZIP

Double-click Install.cmd to install for your Windows account.
Right-click a folder and select massunzip. On Windows 11, use Show more options.
You can also right-click empty space inside a folder.

All ZIPs in the selected folder and its subfolders are extracted into individual
folders. ZIPs contained inside extracted ZIPs are also processed. Existing folders
are preserved by choosing a numbered extraction folder. Junctions and symbolic
links are skipped.

Each extracted file is compared with its archive entry using size and SHA-256.
Only after successful verification is its original ZIP permanently deleted
(not sent to the Recycle Bin). Failed ZIPs are kept. Partial extraction folders
may remain after failures; their paths are shown in the results window.

Encrypted ZIPs and formats other than ZIP are not supported. Leave the results
window open until processing finishes. Avoid launching twice on the same folder.

Double-click Uninstall.cmd to remove the context menu and installed script.
