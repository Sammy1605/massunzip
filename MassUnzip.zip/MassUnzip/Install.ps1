$ErrorActionPreference = 'Stop'
$app = Join-Path $env:LOCALAPPDATA 'MassUnzip'
New-Item -ItemType Directory -Path $app -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'MassUnzip.ps1') -Destination $app -Force
$powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
foreach ($entry in @(@('Directory','%1'), @('Directory\Background','%V'), @('Drive','%1'))) {
    $key = 'HKCU:\Software\Classes\' + $entry[0] + '\shell\MassUnzip'
    New-Item -Path $key -Force | Out-Null
    Set-Item -LiteralPath $key -Value 'massunzip'
    New-ItemProperty -LiteralPath $key -Name Icon -Value $powershell -PropertyType String -Force | Out-Null
    New-Item -Path ($key + '\command') -Force | Out-Null
    $command = '"' + $powershell + '" -NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $app 'MassUnzip.ps1') + '" -Folder "' + $entry[1] + '"'
    Set-Item -LiteralPath ($key + '\command') -Value $command
}
Write-Host 'Installed. Right-click a folder and choose massunzip. On Windows 11, look under Show more options.'
