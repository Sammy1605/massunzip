$ErrorActionPreference = 'Stop'
foreach ($kind in @('Directory','Directory\Background','Drive')) {
    $key = 'HKCU:\Software\Classes\' + $kind + '\shell\MassUnzip'
    if (Test-Path -LiteralPath $key) { Remove-Item -LiteralPath $key -Recurse -Force }
}
$script = Join-Path $env:LOCALAPPDATA 'MassUnzip\MassUnzip.ps1'
if (Test-Path -LiteralPath $script) { Remove-Item -LiteralPath $script -Force }
Write-Host 'MassUnzip removed.'
