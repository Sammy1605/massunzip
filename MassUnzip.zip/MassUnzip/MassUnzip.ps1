param([Parameter(Mandatory=$true)][string]$Folder, [switch]$NoPause)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$ok = 0; $failed = 0
$seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
function Find-Zips([string]$Path) {
    foreach ($item in Get-ChildItem -LiteralPath $Path -Force -ErrorAction Stop) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
        if ($item.PSIsContainer) { Find-Zips $item.FullName }
        elseif ($item.Extension -ieq '.zip') { $item }
    }
}
try {
    $root = Get-Item -LiteralPath $Folder
    if (-not $root.PSIsContainer) { throw 'Select a folder.' }
    $prefix = $root.FullName.TrimEnd('\') + '\'
    Write-Host "MassUnzip: $($root.FullName)"
    Write-Host 'ZIP files are deleted only after extraction and content verification.'
    do {
        $batch = @(Find-Zips $root.FullName | Where-Object { $seen.Add($_.FullName) })
        foreach ($zip in $batch) {
            $archive = $null
            $stage = $null
            try {
                Write-Host "Extracting $($zip.Name)..."
                $dest = Join-Path $zip.DirectoryName $zip.BaseName
                $n = 1
                while (Test-Path -LiteralPath $dest) {
                    $dest = Join-Path $zip.DirectoryName ($zip.BaseName + ' - extracted ' + $n)
                    $n++
                }
                $stage = Join-Path $zip.DirectoryName ('.massunzip-' + [Guid]::NewGuid().ToString('N'))
                $stagePrefix = [IO.Path]::GetFullPath($stage).TrimEnd('\') + '\'
                $archive = [IO.Compression.ZipFile]::OpenRead($zip.FullName)
                foreach ($entry in $archive.Entries) {
                    $relative = $entry.FullName.Replace('/', '\')
                    if ($relative.Contains(':') -or [IO.Path]::IsPathRooted($relative)) { throw 'Unsafe ZIP entry path.' }
                    $target = [IO.Path]::GetFullPath((Join-Path $stage $relative))
                    if (-not $target.StartsWith($stagePrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'ZIP entry escapes its extraction folder.' }
                }
                [IO.Compression.ZipFileExtensions]::ExtractToDirectory($archive, $stage)
                foreach ($entry in $archive.Entries) {
                    if ([string]::IsNullOrEmpty($entry.Name)) { continue }
                    $target = Join-Path $stage $entry.FullName
                    if ((Get-Item -LiteralPath $target).Length -ne $entry.Length) { throw 'File size verification failed.' }
                    $stream = $entry.Open()
                    $sha = [Security.Cryptography.SHA256]::Create()
                    try { $expected = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '') }
                    finally { $stream.Dispose(); $sha.Dispose() }
                    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $expected) { throw 'File content verification failed.' }
                }
                $archive.Dispose(); $archive = $null
                [IO.Directory]::Move($stage, $dest)
                $stage = $null
                if (-not $zip.FullName.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'ZIP outside selected folder.' }
                Remove-Item -LiteralPath $zip.FullName -Force
                $ok++
                Write-Host "Done: $($zip.Name)" -ForegroundColor Green
            } catch {
                $failed++
                Write-Host "ZIP retained: $($zip.FullName) -- $($_.Exception.Message)" -ForegroundColor Yellow
                if ($stage) { Write-Host "Partial extraction, if present: $stage" }
            } finally { if ($null -ne $archive) { $archive.Dispose() } }
        }
    } while ($batch.Count -gt 0)
} catch { $failed++; Write-Host $_.Exception.Message -ForegroundColor Red }
Write-Host "Finished: $ok ZIP files extracted and deleted; $failed errors."
if (-not $NoPause) { [void](Read-Host 'Press Enter to close') }
if ($failed -gt 0) { exit 1 }
